package Lab13;

public interface EnterSpaceIn {

	 String enterSpace(String s);
}
