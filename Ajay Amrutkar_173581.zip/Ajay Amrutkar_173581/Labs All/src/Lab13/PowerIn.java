package Lab13;

public interface PowerIn {

	 double power(int x,int y);
}
