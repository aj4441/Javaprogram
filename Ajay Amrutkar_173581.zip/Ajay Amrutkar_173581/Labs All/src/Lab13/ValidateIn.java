package Lab13;

public interface ValidateIn {

	boolean isValid(String userName,String password);
}
