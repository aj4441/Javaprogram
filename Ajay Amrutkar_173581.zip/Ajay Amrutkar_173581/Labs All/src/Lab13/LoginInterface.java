package Lab13;

@FunctionalInterface
public interface LoginInterface {

	String showData();
}
