package Lab13;

import java.util.Scanner;

public class ValidateClass {

	public static void main(String[] args) {
		String u="ajay";
		String p="gamer";
		@SuppressWarnings("resource")
		Scanner sc= new Scanner(System.in);
		ValidateIn v=(user,pass)->{if(user.equals(u)&&pass.equals(p))return true; else return false;};
		System.out.println("enter username:");
		String user= sc.next();
		System.out.println("enter password");
		String pass= sc.next();
		boolean i=v.isValid(user,pass);
		if(i==true)
			System.out.println("correct login");
		else
			System.out.println("incorrect login");
	}
}
