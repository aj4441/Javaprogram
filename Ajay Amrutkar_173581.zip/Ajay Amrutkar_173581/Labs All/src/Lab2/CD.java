package Lab2;
public class CD extends MediaItem {
	private String genre;
	private String artist;

	public CD(int uid, String title, int noOfCopies, int runtime, String genre,
			String artist) {
		super(uid, title, noOfCopies, runtime);
		this.genre = genre;
		this.artist = artist;
	}

	@Override
	public void addItem() {
		System.out.println("This CD is added");
	}

	@Override
	public void removeItem() {
		System.out.println("This CD is removed from library");
	}

	@Override
	public void checkOut() {
		System.out.println("this CD is alloted to the user");
	}

}
