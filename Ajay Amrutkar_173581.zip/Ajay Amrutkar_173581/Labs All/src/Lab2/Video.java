package Lab2;
public class Video extends MediaItem {

	private String director;
	private String genre;
	private String yearReleased;

	public Video(int uid, String title, int noOfCopies, int runtime,
			String director, String genre, String yearReleased) {
		super(uid, title, noOfCopies, runtime);
		this.director = director;
		this.genre = genre;
		this.yearReleased = yearReleased;
	}

	@Override
	public void addItem() {
		System.out.println("This Video is added");
	}

	@Override
	public void removeItem() {
		System.out.println("This Video is removed from library");
	}

	@Override
	public void checkOut() {
		System.out.println("this Video is alloted to the user");
	}

}
