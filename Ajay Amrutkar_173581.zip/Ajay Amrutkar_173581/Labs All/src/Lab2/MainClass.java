package Lab2;
public class MainClass {
	public static void main(String[] args) {
		Book b1 = new Book(1, "The Alchemist", 10);
		JournalPaper jp = new JournalPaper(2, "automation Project", 10, "2001");
		Video v1 = new Video(4, "Gangs of Wasseypur", 5, 2, "Anurag Kashyap",
				"BollyWood", "2012");
		CD c = new CD(5, "Annable", 5, 3, "Horror", "Blake lively");
		b1.addItem();
		b1.removeItem();
		b1.checkOut();
		jp.addItem();
		jp.removeItem();
		jp.checkOut();
		v1.addItem();
		v1.removeItem();
		v1.checkOut();
		c.addItem();
		c.removeItem();
		c.checkOut();
	}

}
