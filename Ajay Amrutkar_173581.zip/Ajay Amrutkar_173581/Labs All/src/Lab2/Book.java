package Lab2;

public class Book extends WrittenItem {

	@Override
	public String toString() {
		return "Book [lib=" + lib + "]";
	}

	public Book(int uid, String title, int noOfCopies) {
		super(uid, title, noOfCopies);
	}

	@Override
	public void removeItem() {
		System.out.println("This Book is removed from library");

	}

	@Override
	public void checkOut() {
		System.out.println("this book is alloted to the user");

	}

	@Override
	public void addItem() {
		System.out.println("This book is added");

	}

}
