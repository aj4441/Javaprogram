package Lab2;
public abstract class MediaItem extends Item {

	public MediaItem(int uid, String title, int noOfCopies, int runtime) {
		super(uid, title, noOfCopies);
		this.runtime = runtime;
	}

	private int runtime;
}
