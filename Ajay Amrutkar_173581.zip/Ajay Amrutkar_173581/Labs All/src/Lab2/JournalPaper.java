package Lab2;
public class JournalPaper extends WrittenItem {

	public JournalPaper(int uid, String title, int noOfCopies,
			String yearPublished) {
		super(uid, title, noOfCopies);
		this.yearPublished = yearPublished;
	}

	private String yearPublished;

	@Override
	public void addItem() {
		System.out.println("This JournalPaper is added");
	}

	@Override
	public void removeItem() {
		System.out.println("This JournalPaper is removed from library");
	}

	@Override
	public void checkOut() {
		System.out.println("this JournalPaper is alloted to the user");
	}

}
