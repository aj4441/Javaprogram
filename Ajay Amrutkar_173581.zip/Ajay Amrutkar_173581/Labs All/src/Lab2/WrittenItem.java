package Lab2;


public abstract class WrittenItem extends Item {
private String author;

public WrittenItem(int uid, String title, int noOfCopies) {
	super(uid, title, noOfCopies);
}

public void addItem(Book b) {
	
}
}
