package Lab3;

import java.util.Scanner;

public class L33RevArraySortArray {
	void getSorted(int a[], int n) {
		int num = 0, rem = 0, p = 0, rev = 0, temp = 0, b = 0;
		for (int i = 0; i < n; i++) {
			p = a[i];
			rev = 0;
			while (p > 0) {
				rem = p % 10;
				rev = rev * 10 + rem;
				p = p / 10;
			}
			a[i] = rev;
		}
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n - 1; j++) {
				if (a[j] > a[j + 1]) {
					temp = a[j];
					a[j] = a[j + 1];
					a[j + 1] = temp;
				}
			}
		}
		for (int i = 0; i < n; i++) {
			System.out.print(a[i] + "  ");
		}
	}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of array");
		int n = sc.nextInt();
		int a[] = new int[n];
		System.out.println("Enter array element.");
		for (int i = 0; i < n; i++) {
			a[i] = sc.nextInt();
		}
		L33RevArraySortArray obj = new L33RevArraySortArray();
		obj.getSorted(a, n);
	}

}
