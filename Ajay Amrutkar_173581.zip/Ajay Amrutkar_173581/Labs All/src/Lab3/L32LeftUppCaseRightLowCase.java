package Lab3;

import java.util.Scanner;

public class L32LeftUppCaseRightLowCase {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter size of array");
		int n = sc.nextInt();
		String str[] = new String[n];
		System.out.println("Input String are");
		for (int i = 0; i < n; i++)
			str[i] = sc.next();
		System.out.println("Output String are");
		for (int i = 0; i < n; i++) {
			if (i < n / 2 + 1) {
				str[i] = str[i].toUpperCase();
				// System.out.println(str[i]);
			} else
				str[i] = str[i].toLowerCase();
		}
		for (int i = 0; i < n; i++)
			System.out.println(str[i]);
	}

}
