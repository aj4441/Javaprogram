package Lab3;

import java.util.Scanner;

public class L31SecondSmallestElementInArray {
	static int temp = 0;

	static int getSecondSmallest(int a[], int n) {
		int i = 0, b = 0;
		for (i = 0; i < n; i++) {
			for (int j = 0; j < n - 1; j++) {
				if (a[j] > a[j + 1]) {
					temp = a[j];
					a[j] = a[j + 1];
					a[j + 1] = temp;
				}
			}
		}
		return a[1];
	}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int temp = 0;
		System.out.println("Enter the array size.");
		int n = sc.nextInt();
		int a[] = new int[n];
		System.out.println("Enter array element");
		for (int i = 0; i < n; i++) {
			a[i] = sc.nextInt();
		}
		// SecondSmallest obj=new SecondSmallest();
		System.out.println(getSecondSmallest(a, n));
	}

}
