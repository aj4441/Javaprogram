package Lab1;

import java.util.Scanner;

public class L12DiffSumNatNo {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the no");
		int n=scan.nextInt();
		int sum=0,sum1=0,temp=0,sum2=0;
		
		for(int i=1;i<=n;i++){
			sum1=sum1+i*i;						
		}
		for(int i=1;i<=n;i++){
			temp=temp+i;        				
		}
		sum2=(int) Math.pow(temp,2);		
		sum=sum2-sum1;
		System.out.println(sum);
	}
	
}
