package Lab1;

import java.util.Scanner;

public class L11SumNatNo {
	
	public static void main(String[] args) {
		int sum=0;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the no");
		int n=scan.nextInt();
		
		for(int i=1;i<=n;i++){
			if(i%3==0|| i%5==0){
				
				sum=sum+i;
						
			}
		}
		
System.out.println("sum of natural no"+sum);
		
	}

}
