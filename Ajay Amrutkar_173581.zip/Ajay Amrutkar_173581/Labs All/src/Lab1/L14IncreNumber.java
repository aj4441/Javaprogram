package Lab1;

import java.util.Scanner;

public class L14IncreNumber {
	public static void main(String[] args) {   // main method
		int num;
		boolean flag = false;
		Scanner scan = new Scanner(System.in); //create scan object to read user input values
		System.out.println("Enter a number");
		num = scan.nextInt();

		int currentDigit = num % 10;
		num = num / 10;

		while (num > 0) {
			if (currentDigit <= num % 10) {
				flag = true;
				break;
			}
			currentDigit = num % 10;
			num = num / 10;
		}

		if (flag) {
			System.out.println("Digits are not in increasing order.");
		} else {
			System.out.println("Digits are in increasing order.");
		}
	}
}
