package Lab1;

import java.util.Scanner;

public class L13PowOf2 {

	boolean b = false;

	boolean checkNumber(int n) {

		while (n > 0) {
			if (n == 2) {
				break;
			} else if (n % 2 ==
0) {
				b = true;
			} else {
				b = false;
			}
			n = n / 2;
		}
		return b;
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("enter of power of 2");
		int n = scan.nextInt();
		L13PowOf2 obj = new L13PowOf2();
		System.out.println(obj.checkNumber(n));

	}
}
