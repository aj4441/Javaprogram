package Lab5;

//exception class
class EmpException extends Exception {
	public EmpException() {
	}

	public EmpException(String msg) {
		super(msg);
	}

}

class EmployeeName {
	String firstName;
	String lastName;

	public EmployeeName() {

	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	// parameterized constructor
	public EmployeeName(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
	}

	// logic to validate name
	public void validateName() throws EmpException {
		if ((this.firstName != null && this.firstName.indexOf(" ") != 0)
				&& (this.lastName != null && this.lastName.indexOf(" ") != 0))
			System.out.println(firstName + " " + lastName + " is valid name");
		else
			throw new EmpException("Enter valid name");
	}
}

public class EmployeeValidate {
	public static void main(String[] args) {
		EmployeeName emp = new EmployeeName(" ", "Amrutkar");
		EmployeeName emp2 = new EmployeeName("Ajay", "Amrutkar");
		try {
			// valid input
			emp2.validateName();
			// invalid input
			emp.validateName();
		} catch (EmpException e) {
			// if invalid
			System.out.println(e.getMessage());
		}

	}
}
