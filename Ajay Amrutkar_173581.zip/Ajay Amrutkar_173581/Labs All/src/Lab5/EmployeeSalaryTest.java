package Lab5;

public class EmployeeSalaryTest {

	public static void main(String[] args) {
		Employee emp1 = new Employee("Ajay", 4000);
		Employee emp2 = new Employee("Aditya",2000);
		Employee emp3 = new Employee("Tushar",3000);
		

			emp1.checkSalary();
			emp2.checkSalary();
			emp3.checkSalary();
	}

}
