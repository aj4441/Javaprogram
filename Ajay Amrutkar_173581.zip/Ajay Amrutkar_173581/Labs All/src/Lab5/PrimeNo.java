package Lab5;

import java.util.Scanner;

public class PrimeNo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter nth digit to print prime no. till that no");
		
		//take user input
		int num = sc.nextInt();
		boolean flag = false;
		
		//code logic
		for (int i = 2; i <= num; i++) {
			for (int j = 2; j <= i / 2; j++) {
				if (i % j == 0) {
					flag = true;
					break;
				}
			}
			if (!flag)
				System.out.print(i + " ");
			flag = false;
		}
	}
}
