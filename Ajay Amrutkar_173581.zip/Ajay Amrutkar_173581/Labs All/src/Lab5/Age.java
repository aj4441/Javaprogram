package Lab5;

//Exception class
class IllegalAgeException extends Exception {

	public IllegalAgeException() {
		super();
	}

	public IllegalAgeException(String message) {
		super(message);
	}
}

public class Age {
	int age;

	public Age(int age) {
		this.age = age;
	}

	public static void main(String[] args) throws IllegalAgeException {

		Age ageObj = new Age(14);

		if (ageObj.age > 15) {
			System.out.println("Valid Age");
		} else
			//if invalid then throw exception and display appropriate message
			try {
				throw new IllegalAgeException("Age should be above 15");
			} catch (IllegalAgeException e)

			{
				System.out.println(e.getMessage());
			}
	}

}
