package Lab5;

public class TrafficLight {

	// variable to store color
	private String colorLight;

	public TrafficLight(String colourOfLight) {

		this.colorLight = colourOfLight;
	}

	// method to manipulate lights
	public String trafficFlow() {

		if (colorLight.equals("red")) {
			return "stop";
		} else if (colorLight.equals("yellow")) {
			return "ready";
		} else if (colorLight.equals("green")) {
			return "go";
		}
		return "wrong color";

	}
}
