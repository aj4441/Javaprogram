package Lab8;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Scanner;

public class DateFormats {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		// get date from user
		System.out.println("Enter date in format of yyyy-mm-dd");
		String date = scan.next();

		// parse to date
		LocalDate userDate = LocalDate.parse(date);

		LocalDate todayDate = LocalDate.now();

		// find diffrence
		long daysBetween = ChronoUnit.DAYS.between(userDate.withDayOfMonth(1),
				todayDate.withDayOfMonth(1));
		long monthsBetween = ChronoUnit.MONTHS.between(
				userDate.withDayOfMonth(1), todayDate.withDayOfMonth(1));
		long yearsBetween = ChronoUnit.YEARS.between(userDate.withDayOfYear(1),
				todayDate.withDayOfYear(1));

		// print it
		System.out.println("Days Difference " + daysBetween);
		System.out.println("Month Difference " + monthsBetween);
		System.out.println("Year Difference " + yearsBetween);
	}

}
