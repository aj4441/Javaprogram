package com.cg.eis.bean;

public class Employee {
	private String name;
	private String designation;
	private double salary;
	private String insuranceScheme;
	
	
	
	public Employee() {
	}
	
	
	
	public Employee(String name, String designation, double salary) {
		this.name = name;
		this.designation = designation;
		this.salary = salary;
	}



	public String getName() {
		return name;
	}
	public String getDesignation() {
		return designation;
	}
	public double getSalary() {
		return salary;
	}
	public String getInsuranceScheme() {
		return insuranceScheme;
	}

	
	public void setName(String name) {
		this.name = name;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name
				+ ", designation=" + designation + ", salary=" + salary +"]";
	}
	
}
