package com.cg.eis.service;

import java.util.Map;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.DaoClass;
import com.cg.eis.dao.DaoInterface;
import com.cg.eis.exception.EmployeeException;

public class EmployeeService implements EmployeeInterface {

	DaoInterface dao = new DaoClass();

	@Override
	public Employee storeEmployee(Employee employee) {
		return dao.storeEmployee(employee);
	}

	@Override
	public Map<Integer, Employee> displayEmployees() {
		return dao.displayEmployees();
	}

	@Override
	public Employee displayEmployeeById(int id) throws EmployeeException{
		try {
			return dao.displayEmployeeById(id);
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}

	@Override
	public String getInsuranceScheme(int id) throws EmployeeException{
		try {
			return dao.getInsuranceScheme(id);
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}


}
