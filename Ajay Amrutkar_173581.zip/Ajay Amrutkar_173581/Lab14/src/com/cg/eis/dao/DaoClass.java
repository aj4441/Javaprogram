package com.cg.eis.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public class DaoClass implements DaoInterface {

	Map<Integer, Employee> database = new HashMap();

	@Override
	public Employee storeEmployee(Employee employee) {
		database.put((int) (Math.random() * 100), employee);
		return employee;
	}

	@Override
	public Map<Integer, Employee> displayEmployees() {
		return database;
	}

	@Override
	public Employee displayEmployeeById(int id) throws EmployeeException{
		if(database.containsKey(id))
			return database.get(id);
		else
			throw new EmployeeException("Employee Not Found");
	}

	@Override
	public String getInsuranceScheme(int id) throws EmployeeException {
		if(database.containsKey(id))
		{
			Employee employee = database.get(id);
			if(employee.getSalary()<5000 && employee.getDesignation().equalsIgnoreCase("clerk")){
				return "No insurance scheme for clerk";
			}
			else if(employee.getSalary()>=40000 && employee.getDesignation().equalsIgnoreCase("manager")){
				return "You are eligible for insurance scheme A";
			}
			else if(employee.getSalary()>=20000 && employee.getSalary()<40000 && employee.getDesignation().equalsIgnoreCase("Programmer")){
				return "You are eligible for insurance scheme B";
			}
			else{
				return "You are eligible for insurance scheme C";
			}
		}
		else
			throw new EmployeeException("Employee Not Found");
	}

}
