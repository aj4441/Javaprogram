package com.xyz.service;

import java.util.List;

import com.xyz.bean.Vehicle;

public interface IInsuranceService {
	List<Vehicle> fetchVehicles();
	
	long calculateInsurance(Vehicle vehicle,String type);
	boolean validateInput(String choice);
	
	String userChoice="[1-2]{1}";
	double fivePer = 0.05;
	double threePer = 0.03;
	double ninetyPer = 0.90;
	double ninetyFivePer = 0.95;

}
