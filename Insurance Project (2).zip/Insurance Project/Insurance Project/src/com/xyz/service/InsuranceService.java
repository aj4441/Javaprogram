package com.xyz.service;

import java.time.LocalDate;
import java.util.List;

import com.xyz.bean.Vehicle;
import com.xyz.dao.IInsuranceDao;
import com.xyz.dao.InsuranceDAO;

public class InsuranceService implements IInsuranceService{

	IInsuranceDao dao = new InsuranceDAO();
	
	//fetch all data
	@Override
	public List<Vehicle> fetchVehicles() {
		return dao.fetchVehicles();
	}
	
	
	
	@Override
	public long calculateInsurance(Vehicle vehicle, String type) {	
		
		//get model year in int
		int modelYear = Integer.parseInt(vehicle.getDate());
		
		//calculate difference in int
		int yearGap = LocalDate.now().getYear() - modelYear;
		
		//will store degraded amount of vehicle
		long degradedPrice = 0;
		
		//if less than 3 then will degrade by 5% or by 10%
		if(yearGap<=3)
			degradedPrice = (long) (vehicle.getPrice() * ninetyFivePer);
		else
			degradedPrice = (long) (vehicle.getPrice() * ninetyPer);
		
		//choice of insurance
		if(type.equals("1"))
			return (long) (degradedPrice * fivePer);
		else
			return (long) (degradedPrice * threePer);
	}
	
	//validate choice is between 1-2
	@Override
	public boolean validateInput(String choice) {
		if(choice.matches(userChoice))
			return true;
		return false;
	}

}
