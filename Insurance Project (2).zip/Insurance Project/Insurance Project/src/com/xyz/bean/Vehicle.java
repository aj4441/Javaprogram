package com.xyz.bean;

public class Vehicle {
	private String name;
	private long price;
	private String date;
	public Vehicle(String name, long price, String date) {
		super();
		this.name = name;
		this.price = price;
		this.date = date;
	}
	@Override
	public String toString() {
		return "Vehicle name=" + name + ", Model Year=" + date;
	}
	public String getName() {
		return name;
	}
	public long getPrice() {
		return price;
	}
	public String getDate() {
		return date;
	}
	
}
