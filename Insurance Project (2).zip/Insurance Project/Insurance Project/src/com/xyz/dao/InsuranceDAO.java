package com.xyz.dao;

import java.util.ArrayList;
import java.util.List;

import com.xyz.bean.Vehicle;

public class InsuranceDAO implements IInsuranceDao{

	List<Vehicle> database;

	public InsuranceDAO() {
		database = new ArrayList<Vehicle>();
		
		database.add(new Vehicle("KTM 250", 150000, "2014"));
		database.add(new Vehicle("Pulsar 220", 120000, "2012"));
		database.add(new Vehicle("CBR 250", 120000, "2015"));
		database.add(new Vehicle("Unicorn 250", 90000, "2017"));
		database.add(new Vehicle("Splender", 60000, "2010"));
	}

	@Override
	public List<Vehicle> fetchVehicles() {
		return database;
	}
	
	
}
