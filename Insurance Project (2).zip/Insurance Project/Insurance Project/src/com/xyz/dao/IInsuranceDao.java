package com.xyz.dao;

import java.util.List;

import com.xyz.bean.Vehicle;

public interface IInsuranceDao {

	List<Vehicle> fetchVehicles();
}
