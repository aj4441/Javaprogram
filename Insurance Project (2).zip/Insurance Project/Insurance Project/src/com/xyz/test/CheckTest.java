package com.xyz.test;

import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.xyz.bean.Vehicle;
import com.xyz.service.IInsuranceService;
import com.xyz.service.InsuranceService;

public class CheckTest {

	IInsuranceService service;
	@Before
	public void set()
	{
		service  = new InsuranceService();
	}
	
	@Test
	public void test1()
	{
		List<Vehicle> vehicleData = service.fetchVehicles();
		long result = service.calculateInsurance(vehicleData.get(0), "1");
		Assert.assertEquals(6750, result);
	}
	
	@Test
	public void test2()
	{
		List<Vehicle> vehicleData = service.fetchVehicles();
		long result = service.calculateInsurance(vehicleData.get(1), "2");
		Assert.assertEquals(3240, result);
	}
	
	@After
	public void destroy()
	{
		service = null;
	}
}
