package com.xyz.ui;

import java.util.List;
import java.util.Scanner;

import com.xyz.bean.Vehicle;
import com.xyz.service.IInsuranceService;
import com.xyz.service.InsuranceService;

public class CustomerUI {

	public static void main(String[] args) {

		// instantiate service class
		IInsuranceService service = new InsuranceService();
		Scanner scan = new Scanner(System.in);

		// fetch all available data of vehicles
		List<Vehicle> vehicleData = service.fetchVehicles();

		System.out.println("Welcome to XYZ Insurance Portal\n");
		System.out.println("#. Name\t\tModel Year");

		int counter = 1;

		// display vehicles with choices
		for (Vehicle vehicle : vehicleData) {
			System.out.println(counter++ + ". " + vehicle.getName() + "\t"
					+ vehicle.getDate());
		}

		// will store vehicle choice
		int vehicleChoice = 0;

		while (true) {
			try {
				System.out.println("Please Select a Vehicle");
				// if input is not in number than it throws exception
				vehicleChoice = Integer.parseInt(scan.next()) - 1;
				// if index doesnt exists then it throws and exception
				vehicleData.get(vehicleChoice);
				break;
			} catch (Exception e) {
				System.out.println("Please Select proper number between 1 and "
						+ vehicleData.size());
			}

		}

		System.out.println("Please select Type of insurance");
		System.out.println("1. Comprehensive\n2. 3rd Party");

		// will store insurance choice
		String insuranceChoice = "";

		while (true) {
			insuranceChoice = scan.next();

			// validate if input is between 1-2
			boolean isValid = service.validateInput(insuranceChoice);
			if (isValid)
				break;
			System.out.println("Please Choose between 1-2");
		}

		// call the method
		long result = service.calculateInsurance(
				vehicleData.get(vehicleChoice), insuranceChoice);

		System.out.println("Your Insurance will be Rs." + result);
	}
}
