package com.capgemini.xyz.ui;

import java.util.List;
import java.util.Scanner;

import com.capgemini.xyz.bean.Vehicle;
import com.capgemini.xyz.service.InsuranceService;
import com.capgemini.xyz.service.InsuranceServiceInterface;

public class Main {

	public static void main(String[] args) {
		InsuranceServiceInterface isi = new InsuranceService();
		Scanner sc = new Scanner(System.in);
		int vehicleChoice, insuranceType, a = 1;
		int yearOfPurchase;
		float depricatedValuePercent;
		double vehiclePrice;
		double insuranceAmount;

		while (true) {
			// welcome menu
			System.out.println("Welcome to dude insurance company");
			System.out.println("Please select a vehicle:");
			List<Vehicle> vehicleDatabase = isi.fetchVehicleDetails();

			// displaying vehicle details for insurance
			for (Vehicle v : vehicleDatabase) {
				System.out.println(a++ + ")" + v);
			}
			a=1;

			System.out.println("Please select a vehicle:");
			vehicleChoice = sc.nextInt();
			if (vehicleChoice > 0 && vehicleChoice < 6) {
				// System.out.println(vehicleDatabase.get(vehicleChoice-1).getPrice());
				
				System.out.println("Enter year of bike purchase");
				yearOfPurchase = sc.nextInt();
				while (true) {
					
					System.out.println("Select type of insurance:");
					System.out.println("1) Comprehensive \n2) Third Party");
					insuranceType = sc.nextInt();
					if (insuranceType > 0 && insuranceType < 3) {

						//calculating depricated value of vehicle
						depricatedValuePercent = isi
								.calculateDepricatedValuePercent(yearOfPurchase);
						//fetching price of the vehicle user selected
						vehiclePrice = vehicleDatabase.get(vehicleChoice - 1)
								.getPrice();
						insuranceAmount = isi.calculateInsuranceAmount(
								depricatedValuePercent, insuranceType,
								vehiclePrice);
						System.out.println("Your insurance amount is: "
								+ insuranceAmount);
						break;
					} else {
						System.out.println("Invalid choice");
					}
				}
			} else {
				System.out.println("Invalid choice");
			}
		}
	}
}
