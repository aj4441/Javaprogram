package com.capgemini.xyz.dao;

import java.util.List;

import com.capgemini.xyz.bean.Vehicle;

public interface InsuranceInterfaceDao {

	void insertVehicleDetails(Vehicle vehicle);

	List<Vehicle> fetchVehicleDetails();
	
	

}
