package com.capgemini.xyz.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.xyz.bean.Vehicle;

public class InsuranceDao implements InsuranceInterfaceDao {

	List<Vehicle> vehicleDatabase = new ArrayList<Vehicle>();

	public InsuranceDao() {
		Vehicle ktm = new Vehicle("KTM 250", 150000);
		Vehicle pulsar = new Vehicle("Pulsar 220", 120000);
		Vehicle cbr = new Vehicle("CBR 150", 110000);
		Vehicle unicorn = new Vehicle("Unicporn 150", 90000);
		Vehicle splender = new Vehicle("Splender 110", 60000);
		insertVehicleDetails(ktm);
		insertVehicleDetails(pulsar);
		insertVehicleDetails(cbr);
		insertVehicleDetails(unicorn);
		insertVehicleDetails(splender);
	}

	@Override
	public void insertVehicleDetails(Vehicle vehicle) {
		vehicleDatabase.add(vehicle);
	}

	@Override
	public List<Vehicle> fetchVehicleDetails() {
		return vehicleDatabase;

	}

}
