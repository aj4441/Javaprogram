package com.capgemini.xyz.bean;

public class Vehicle {

	private String name;
	private double price;
	private String date;

	
	public String getName() {
		return name;
	}
	
	public Vehicle(String name, double price) {
		super();
		this.name = name;
		this.price = price;
		this.date = date;
	}
	@Override
	public String toString() {
		return "Vehicle [name=" + name + ", price=" + price+"]";
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
}
