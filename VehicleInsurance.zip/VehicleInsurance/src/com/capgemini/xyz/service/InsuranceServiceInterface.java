package com.capgemini.xyz.service;

import java.util.List;

import com.capgemini.xyz.bean.Vehicle;

public interface InsuranceServiceInterface {

	float calculateDepricatedValuePercent(int yearOfPurchase);

	double calculateInsuranceAmount(float depricatedValuePercent,
			int insuranceType, double vehiclePrice);

	boolean validateDate();

	List<Vehicle> fetchVehicleDetails();

	double CURRENT_YEAR = 2019;

	float DEPRICATED_VALUE_UPTO_3_YEARS = 0.05f;

	float DEPRICATED_VALUE_AFTER_3_YEARS = 0.1F;

	float COMPREHENSICE_PERCENT = 0.05f;

	float THIRD_PARTY_INSURANCEPERCENT = 0.03f;

	int THRESHOLD_YEAR_VALUE = 3;

}
