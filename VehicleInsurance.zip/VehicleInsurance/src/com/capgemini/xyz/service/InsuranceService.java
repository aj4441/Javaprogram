package com.capgemini.xyz.service;

import java.util.List;

import com.capgemini.xyz.bean.Vehicle;
import com.capgemini.xyz.dao.InsuranceDao;
import com.capgemini.xyz.dao.InsuranceInterfaceDao;

public class InsuranceService implements InsuranceServiceInterface {

	InsuranceInterfaceDao idao = new InsuranceDao();
	double insuranceAmount;

	// calculating depricated value of the bike according to year of purchase of
	// bike
	@Override
	public float calculateDepricatedValuePercent(int yearOfPurchase) {
		if (CURRENT_YEAR - yearOfPurchase <= THRESHOLD_YEAR_VALUE) {
			return DEPRICATED_VALUE_UPTO_3_YEARS;
		} else {
			return DEPRICATED_VALUE_AFTER_3_YEARS;
		}

	}

	// calculating Insurance Amount value of the bike according to depricated
	// value of bike and insurance type
	@Override
	public double calculateInsuranceAmount(float depricatedValuePercent,
			int insuranceType, double vehiclePrice) {

		insuranceAmount = vehiclePrice - vehiclePrice * depricatedValuePercent;

		if (insuranceType == 1) {
			insuranceAmount = insuranceAmount * COMPREHENSICE_PERCENT;
		} else {
			insuranceAmount = insuranceAmount * THIRD_PARTY_INSURANCEPERCENT;
		}
		return insuranceAmount;
	}

	@Override
	public boolean validateDate() {

		return false;
	}

	@Override
	public List<Vehicle> fetchVehicleDetails() {
		return (idao.fetchVehicleDetails());
	}

}
