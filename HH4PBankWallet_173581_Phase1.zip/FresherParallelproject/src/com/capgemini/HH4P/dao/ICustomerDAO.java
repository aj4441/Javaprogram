package com.capgemini.HH4P.dao;

import java.util.List;

import com.capgemini.HH4P.bean.Customer;
import com.capgemini.HH4P.bean.Transaction;
import com.capgemini.HH4P.exception.CustomerExists;
import com.capgemini.HH4P.exception.CustomerNotFoundException;
import com.capgemini.HH4P.exception.InsufficientBalanceException;

public interface ICustomerDAO {

	Customer createCustomer(Customer customer) throws CustomerExists;

	String withDraw(String mobileNumber, double amount)	throws InsufficientBalanceException;

	String deposit(String mobileNumber, double amount);

	Customer checkUser(String username, String password) throws CustomerNotFoundException;

	List<Transaction> printTransaction(Customer customer);

	double checkBalance(Customer customer);

	long ids = 10002;
}
