package com.capgemini.xyz.service;

import java.util.ArrayList;
import java.util.Map;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.dao.StoreUserdata;

public class ValidateUserInput implements ValidateInterface {
	StoreUserdata data = new StoreUserdata();// creating object for calling DAO methods(storeToMap,displayDetails)

	@Override
	public boolean validateUserName(String userName) {
		if (userName.matches(USER_NAME_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateAddress(String address) {
		if (address.matches(ADDRESS_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateMobile(String mobile) {
		if (mobile.matches(MOBILE_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateEmail(String email) {
		if (email.matches(EMAIL_PATTERN))
			return true;
		else
			return false;
	}

	public void StoreIntoMap(Customer customer) {
		data.storeIntoMap(customer); // calliing backend method o store data in map 
	}

	@Override
	public ArrayList<Customer> displayCustomers() {
		return data.displayCustomers(); 
	}

	@Override
	public boolean validateLoanAmount(String amount) {
		if (amount.matches(LOAN_AMOUNT))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateLoanDuration(String duration) {
		if (duration.matches(LOAN_DURATION))
			return true;
		else
			return false;
	}

}
