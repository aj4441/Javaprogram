package com.capgemini.xyz.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import com.capgemini.xyz.bean.Customer;

public interface StoreDataInterFace {
	//creating methods for override
	void storeIntoMap(Customer customer);

	ArrayList<Customer> displayCustomers();
}
